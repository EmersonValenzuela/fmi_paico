'use strict';
$(function() {
    $('.datatables-demo').footable({
        "paging": {
            "enabled": true
        },
        "sorting": {
            "enabled": true
        }
    });
});
