 <!-- [ Layout content ] Start -->
 <div class="layout-content">

     <!-- [ content ] Start -->
     <div class="container-fluid flex-grow-1 container-p-y">
         <h4 class="font-weight-bold py-3 mb-0">Dashboard</h4>
         <div class="text-muted small mt-0 mb-4 d-block breadcrumb">
             <ol class="breadcrumb">
                 <li class="breadcrumb-item"><a href="#"><i class="feather icon-home"></i></a></li>
                 <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
                 <li class="breadcrumb-item active">Main</li>
             </ol>
         </div>
         <div class="row">
             <!-- Staustic card 9 Start -->
             <h1>Hola MUNDO</h1>
             <!-- Staustic card 9 end -->
         </div>

     </div>
     <!-- [ Layout content ] Start -->
 </div>
 <!-- [ Layout container ] End -->
 </div>
 <!-- Overlay -->
 <div class="layout-overlay layout-sidenav-toggle"></div>
 </div>
 <!-- [ Layout wrapper] End -->