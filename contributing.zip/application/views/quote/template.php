<?php $this->load->view("quote/layout/header"); ?>
<?php $this->load->view("quote/layout/sidebar"); ?>
<?= $contents ?>
<?php $this->load->view("quote/layout/footer"); ?>
 